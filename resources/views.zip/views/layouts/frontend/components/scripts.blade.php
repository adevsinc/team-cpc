<!-- End of Page -->
  <!-- Scripts -->
  <script src="{{ asset('frontend_assets') }}/js/core.bundle.js">
  </script>
  <script src="{{ asset('frontend_assets') }}/vendors/ktui/ktui.min.js">
  </script>
  <script src="{{ asset('frontend_assets') }}/vendors/apexcharts/apexcharts.min.js">
  </script>
  <!-- End of Scripts -->